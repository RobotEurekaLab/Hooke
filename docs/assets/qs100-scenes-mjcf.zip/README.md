# Hooke QS top-100 laboratory scene collection

133 reference-informed mechanical scene prototypes at 102 institutions in the repository's pinned QS 2027 rank <=100 roster, including ties.

Each scene directory contains scene.xml, manifest.json and any required assets/. Extract the entire archive before opening scene.xml with MuJoCo. All model paths are relative; no Hooke checkout is needed to compile them.

Models were generated from the published Hooke source and compiled with MuJoCo. This publication check does not repeat dynamics, robot tasks or scientific validation. The models are estimated reconstructions, not surveyed or institution-validated twins. They do not provide validated native Isaac articulations.

The website uses previously recorded Blender views; these can predate mechanical refinements in the models. Source photographs, raw logs and Blender intermediates are not included.

Source and rebuild instructions: https://github.com/RobotEurekaLab/Hooke/blob/main/docs/university_labs.md
